package edu.miu.bank.kafka;

public enum TransactionType {
    DEPOSIT, WITHDRAW,TRANSFER,
}
