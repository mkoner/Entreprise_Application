package edu.miu.Lab2PartC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab2PartCApplicationTests {

	@Test
	void contextLoads() {
	}

}
